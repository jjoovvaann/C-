#include <iostream>
#include <vector>
#include <ctime>

using namespace std;

class Animal
{
protected:
    string birthDate;
    string arrivalDate;
    char gender;
    string name;
    string lastVaccinationDate;

public:
    Animal(string birth, string arrival, char g, string n, string lastVacc)
        : birthDate(birth), arrivalDate(arrival), gender(g), name(n), lastVaccinationDate(lastVacc) {}

    void displayInfo()
    {
        cout << "Name: " << name << endl;
        cout << "Birth Date: " << birthDate << endl;
        cout << "Arrival Date: " << arrivalDate << endl;
        cout << "Gender: " << gender << endl;
        cout << "Last Vaccination Date: " << lastVaccinationDate << endl;
    }

    virtual bool needsVaccination() = 0;
};

class Mammal : public Animal
{
public:
    Mammal(string birth, string arrival, char g, string n, string lastVacc)
        : Animal(birth, arrival, g, n, lastVacc) {}

    bool needsVaccination() override
    {
        time_t now = time(0);
        tm* currentTime = localtime(&now);
        int currentYear = currentTime->tm_year + 1900;

        tm lastVaccination;
        strptime(lastVaccinationDate.c_str(), "%Y-%m-%d", &lastVaccination);
        int lastVaccinationYear = lastVaccination.tm_year + 1900;

        return currentYear > lastVaccinationYear;
    }
};

class Bird : public Animal
{
public:
    Bird(string birth, string arrival, char g, string n, string lastVacc)
        : Animal(birth, arrival, g, n, lastVacc) {}

    bool needsVaccination() override
    {

        time_t now = time(0);
        tm* currentTime = localtime(&now);
        int currentMonth = currentTime->tm_mon + 1;
        int currentYear = currentTime->tm_year + 1900;

        tm lastVaccination;
        strptime(lastVaccinationDate.c_str(), "%Y-%m-%d", &lastVaccination);
        int lastVaccinationYear = lastVaccination.tm_year + 1900;
        int lastVaccinationMonth = lastVaccination.tm_mon + 1;

        int monthsPassed = (currentYear - lastVaccinationYear) * 12 + (currentMonth - lastVaccinationMonth);

        return monthsPassed >= 6;
    }
};

class Reptile : public Animal
{
public:
    Reptile(string birth, string arrival, char g, string n, string lastVacc)
        : Animal(birth, arrival, g, n, lastVacc) {}

    bool needsVaccination() override
    {

        time_t now = time(0);
        tm* currentTime = localtime(&now);
        int currentMonth = currentTime->tm_mon + 1;
        int currentYear = currentTime->tm_year + 1900;

        tm lastVaccination;
        strptime(lastVaccinationDate.c_str(), "%Y-%m-%d", &lastVaccination);
        int lastVaccinationYear = lastVaccination.tm_year + 1900;
        int lastVaccinationMonth = lastVaccination.tm_mon + 1;

        int monthsPassed = (currentYear - lastVaccinationYear) * 12 + (currentMonth - lastVaccinationMonth);

        return monthsPassed >= 9;
    }
};

int main()
{
    vector<Animal*> animals;

    int choice;
    do {
        cout << "Menu:\n";
        cout << "1. Add an animal to the list\n";
        cout << "2. Display count of animals\n";
        cout << "3. Display animals of a certain group\n";
        cout << "4. Display the entire list\n";
        cout << "5. Display animals needing vaccination within 1 week\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            char type;
            cout << "Enter type of animal (m/mammal, b/bird, r/reptile): ";
            cin >> type;

            string birthDate, arrivalDate, name, lastVaccinationDate;
            char gender;

            cout << "Enter birth date (YYYY-MM-DD): ";
            cin >> birthDate;
            cout << "Enter arrival date (YYYY-MM-DD): ";
            cin >> arrivalDate;
            cout << "Enter gender (m/f): ";
            cin >> gender;
            cout << "Enter name: ";
            cin >> name;
            cout << "Enter last vaccination date (YYYY-MM-DD): ";
            cin >> lastVaccinationDate;

            Animal* newAnimal;
            if (type == 'm')
            {
                newAnimal = new Mammal(birthDate, arrivalDate, gender, name, lastVaccinationDate);
            } else if (type == 'b')
            {
                newAnimal = new Bird(birthDate, arrivalDate, gender, name, lastVaccinationDate);
            } else if (type == 'r')
            {
                newAnimal = new Reptile(birthDate, arrivalDate, gender, name, lastVaccinationDate);
            } else
            {
                cout << "Invalid type! Animal not added.\n";
                continue;
            }

            animals.push_back(newAnimal);
            cout << "Animal added successfully.\n";
            break;
        }
        case 2:
        {
            cout << "Total number of animals: " << animals.size() << endl;
            break;
        }
        case 3: {
            char group;
            cout << "Enter group to display (m/mammal, b/bird, r/reptile): ";
            cin >> group;

            cout << "Animals in the group:\n";
            for (auto& animal : animals) {
                if (group == 'm' && dynamic_cast<Mammal*>(animal))
                {
                    animal->displayInfo();
                } else if (group == 'b' && dynamic_cast<Bird*>(animal))
                {
                    animal->displayInfo();
                } else if (group == 'r' && dynamic_cast<Reptile*>(animal))
                {
                    animal->displayInfo();
                }
            }
            break;
        }
        case 4:
        {
            cout << "Entire list of animals:\n";
            for (auto& animal : animals)
            {
                animal->displayInfo();
            }
            break;
        }
        case 5:
        {
            time_t now = time(0);
            tm* currentTime = localtime(&now);
            currentTime->tm_mday += 7; // Add 7 days to the current date
            mktime(currentTime); // Normalize the date

            cout << "Animals needing vaccination within 1 week:\
