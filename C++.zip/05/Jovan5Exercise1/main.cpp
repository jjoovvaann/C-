#include <iostream>
#include <ctime>

const int MAX_ANIMALS = 100;

class Date {
private:
    int day, month, year;

public:
    Date(int d, int m, int y) : day(d), month(m), year(y) {}

    friend std::ostream& operator<<(std::ostream& os, const Date& date)
    {
        os << date.day << "." << date.month << "." << date.year;
        return os;
    }
};

class Animal
{
private:
    Date birthDate, arrivalDate, lastVaccinationDate;
    std::string type, gender, name;

public:
    Animal(Date bDate, Date aDate, std::string t, std::string g, std::string n, Date vDate)
        : birthDate(bDate), arrivalDate(aDate), type(t), gender(g), name(n), lastVaccinationDate(vDate) {}

    void displayInfo()
    {
        std::cout << "Name: " << name << ", Type: " << type << ", Gender: " << gender << std::endl;
        std::cout << "Birth Date: " << birthDate << ", Arrival Date: " << arrivalDate << ", Last Vaccination Date: " << lastVaccinationDate << std::endl;
    }

    Date calculateNextVaccination()
    {
        return lastVaccinationDate;
    }
};

Animal zooAnimals[MAX_ANIMALS];
int animalCount = 0;

void addAnimal()
{
    if (animalCount < MAX_ANIMALS)
    {
        int day, month, year;
        std::string name, type, gender;
        std::cout << "Enter animal name: ";
        std::cin >> name;
        std::cout << "Enter animal type: ";
        std::cin >> type;
        std::cout << "Enter animal gender: ";
        std::cin >> gender;
        std::cout << "Enter birth date (day month year): ";
        std::cin >> day >> month >> year;
        Date birth(day, month, year);
        std::cout << "Enter arrival date (day month year): ";
        std::cin >> day >> month >> year;
        Date arrival(day, month, year);
        std::cout << "Enter last vaccination date (day month year): ";
        std::cin >> day >> month >> year;
        Date vaccination(day, month, year);

        zooAnimals[animalCount++] = Animal(birth, arrival, type, gender, name, vaccination);
        std::cout << "Animal added successfully!" << std::endl;
    } else
    {
        std::cout << "Maximum animal limit reached!" << std::endl;
    }
}

void showPopulation()
{
    std::cout << "Total number of animals in the zoo: " << animalCount << std::endl;
}

void showAnimalsByType(char type)
{
    std::cout << "Animals of type '" << type << "':" << std::endl;
    for (int i = 0; i < animalCount; ++i) {
        if (zooAnimals[i].type == std::string(1, type))
        {
            zooAnimals[i].displayInfo();
        }
    }
}

void showEntireList()
{
    std::cout << "List of all animals in the zoo:" << std::endl;
    for (int i = 0; i < animalCount; ++i) {
        zooAnimals[i].displayInfo();
    }
}

void showAnimalsToVaccinateSoon()
{
    std::time_t currentTime = std::time(nullptr);
    const int SEVEN_DAYS = 7 * 24 * 60 * 60;
    std::cout << "Animals needing vaccination within a week:" << std::endl;
    for (int i = 0; i < animalCount; ++i) {
        std::time_t vaccinationTime = std::mktime(&zooAnimals[i].calculateNextVaccination());
        if (vaccinationTime - currentTime < SEVEN_DAYS)
        {
            zooAnimals[i].displayInfo();
        }
    }
}

int main()
{
    while (true)
    {
        std::cout << "Menu:" << std::endl;
        std::cout << "1. Add an animal to the zoo" << std::endl;
        std::cout << "2. Show population statistics" << std::endl;
        std::cout << "3. Show animals by type" << std::endl;
        std::cout << "4. Show the entire list of animals" << std::endl;
        std::cout << "5. Show animals needing vaccination soon" << std::endl;
        std::cout << "6. Exit" << std::endl;

        int choice;
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice)
        {
        case 1:
            addAnimal();
            break;
        case 2:
            showPopulation();
            break;
        case 3:
            char animalType;
            std::cout << "Enter animal type (c - mammals, v - birds, p - reptiles): ";
            std::cin >> animalType;
            showAnimalsByType(animalType);
            break;
        case 4:
            showEntireList();
            break;
        case 5:
            showAnimalsToVaccinateSoon();
            break;
        case 6:
            std::cout << "Exiting..." << std::endl;
            return 0;
        default:
            std::cout << "Invalid choice. Try again." << std::endl;
        }
    }

    return 0;
}

