#include<iostream>
#include<vector>
using namespace std;

class Datum
{
public:
    int dat, month, year;
    Datum(int d, int m, int y) : day(d), month(m), year(y) {}
};

class Artikl
{
protected:
    string ime_na_artikl;
    string golemina;
    double cena;
    Datum donesen_vo_prodavnica;
public:
    Artikl(string ime, string g, double c, Datum d) : ime_na_artikl(ime), golemina(g), cena(c), donesen_vo_prodavnica(d) {}

    void prikazi_podatoci()
    {
        cout<< "ImE: " << ime_na_artikl << "Golemina: " << golemina << "Cena: " << cena <<" Donesen vo prodavnica" << donesen_vo_prodavnica.day << donesen_vo_prodavnica.month << donesen_vo_prodavnica.year << endl;
    }

    virtual void presmetaj_nabavka() = 0;

};

class Pantaloni : public Artikl
{
private:
    Datum datum_na_sledna_nabavka;

public:
    Pantaloni(string ime, string g, double c, Datum d, Datum sledna_nabavka) : Artikl(ime, g, c, d), datum_na_sledna_nabavka(sledna_nabavka) {}

    void prikazi_podatoci()
    {
        Artikl::prikazi_podatoci();
        cout << "Datum na sledna nabavka: " << datum_na_sledna_nabavka.day << "/" << datum_na_sledna_nabavka.month << "/" << datum_na_sledna_nabavka.year << endl;
    }

    void presmetaj_nabavka()
    {
        // ??
    }
};

class Kosuli : public Artikl
{
public:
    Kosuli(string ime, string g, double c, Datum d) : Artikl(ime, g, c, d) {}

    void presmetaj_nabavka()
    {
        // ??
    }
};

void showMenu()
{
    cout << "1. Dodavanje na artikl vo listata" << endl;
    cout << "2. Prikazuvanje na artikli od dadena grupa" << endl;
    cout << "3. Prikazuvanje na celata lista (so vkupna cena)" << endl;
    cout << "4. Prikazuvanje na artiklite koi treba da se nabavat vo rok od 1 nedela i pari koi treba da se potrosat za da se nabavat potrebnite artikli" << endl;
    cout << "5. Izlez od menito" << endl;
}

int main()
{

    Datum pantaloniDatum(15, 12, 2023);
    Datum kosuliDatum(20, 12, 2023);
    Pantaloni pantaloni("Pantaloni", "M", 1000, pantaloniDatum, Datum(20, 12, 2023));
    Kosuli kosuli("Kosuli", "L", 800, kosuliDatum);

    int choice;
    do
    {
        showMenu();
        cout << "Vnesi izbor: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            break;
        case 2:
            break;
        case 3:
            break;
        case 4:
            pantaloni.presmetaj_nabavka();
            kosuli.presmetaj_nabavka();
            break;
        case 5:
            cout << "Izlez od menito." << endl;
            break;
        default:
            cout << "Nevaliden izbor. Obidete se povtorno." << endl;
        }
    } while (choice != 5);

    return 0;
}
