#include<iostream>
using std::cout;
using std::cin;
using std::endl;

class Stedac
{
public:
    void vnesi_podatoci();
    void prikazi_podatoci();
    void uplata(unsigned long i);
    void isplata(unsigned long i);
    long sostojba;

private:
    int broj;
    char imeprezime[30], adresa[50];
    long saldo;
};

void Stedac::vnesi_podatoci()
{
    cout << "Enter number: ";
    cin >> broj;
    cout <<" Enter name and last name";
    cin.getline(imeprezime, 30);
    cout<< "Enter adress";
    cin.getline(adresa, 50);
    saldo = 0;
}

void Stedac::prikazi_podatoci()
{
    cout<<"Number: " << broj << endl;
    cout<<"Name and LastName: "<< imeprezime << endl;
    cout<<"Adress: "<< adresa << endl;
    cout <<"Saldo" << saldo << endl;
}

void Stedac::uplata(unsigned long i)
{
    saldo = saldo + i;
    cout<<"New sum " << saldo << endl;
}

void Stedac::isplata(unsigned long i)
{
    if (saldo >= i)
    {
        saldo -= i;
        std::cout << "New sum: " << saldo << std::endl;
    } else
    {
        std::cout << "Not enough money." << std::endl;
    }
}

int main()
{
    Stedac stedac;

    char choice;
    do
    {
        std::cout << "Menu:" << std::endl;
        std::cout << "a) Vnesi nov stedac" << std::endl;
        std::cout << "b) Prikazi podatoci" << std::endl;
        std::cout << "c) Uplata na sredstva" << std::endl;
        std::cout << "d) Isplata na sredstva" << std::endl;
        std::cout << "e) Prikazi saldo" << std::endl;
        std::cout << "f) Izlez" << std::endl;
        std::cout << "Izberi opcija: ";
        std::cin >> choice;

        switch (choice)
        {
        case 'a':
        {
            stedac.vnesi_podatoci();
            break;
        }
        case 'b':
        {
            stedac.prikazi_podatoci();
            break;
        }
        case 'c':
        {
            unsigned long uplata_iznos;
            std::cout << "Vnesi iznos za uplata: ";
            std::cin >> uplata_iznos;
            stedac.uplata(uplata_iznos);
            break;
        }
        case 'd':
        {
            unsigned long isplata_iznos;
            std::cout << "Vnesi iznos za isplata: ";
            std::cin >> isplata_iznos;
            stedac.isplata(isplata_iznos);
            break;
        }

        case 'f':
        {
            std::cout << "Izlez od programata." << std::endl;
            break;
        }
        default:
        {
            std::cout << "Vnesena e nevalidna opcija. Probajte povtorno." << std::endl;
            break;
        }
        }
    } while (choice != 'f');

    return 0;
}



