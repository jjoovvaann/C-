#include<iostream>
#include<vector>
#include<limits>

using std::cout;
using std::cin;
using std::endl;

class Cube
{
private:
    float length;
    float width;
    float height;
public:
    Cube(float l, float w, float h) : length(l), width(w), height(h) {}
    float getArea()
    {
        return 2 * (length * width + width * height + height * length);
    }
    float getVolume()
    {
        return length * width * height;
    }
    void printDimensions()
    {
        cout << "Dimensions - Length"<< length <<", Width: "<< width<<", Height"<< height<< endl;
    }
    void setDimensions(float l, float w, float h)
    {
        length = l;
        width = w;
        height = h;
    }
};

int main()
{
    std::vector<Cube> cubes;
    char choice;
    do
    {
        cout << "Menu:" << endl;
        cout << "a) Create new object" << endl;
        cout << "b) Set dimensions" << endl;
        cout << "c) Print dimensions of all objects" <<endl;
        cout << "d) Print dimensions of a particular object" << endl;
        cout << "e) Print dimensions satisfying a condition" << endl;
        cout << "f) Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 'a':
        {
            float l, w, h;
            cout << "Enter length, width, and height: ";
            cin >> l >> w >> h;
            Cube newCube(l, w, h);
            cubes.push_back(newCube);
            break;
        }
        case 'b':
        {
            int index;
            float l, w, h;
            cout << "Enter the index of the object: ";
            cin >> index;
            cout << "Enter new length, width, and height: ";
            cin >> l >> w >> h;
            cubes[index].setDimensions(l, w, h);
            break;
        }
        case 'c':
        {
            for (size_t i = 0; i < cubes.size(); ++i)
            {
                cout << "Object " << i << ": ";
                cubes[i].printDimensions();
            }
            break;
        }
        case 'd':
        {
            int index;
            cout << "Enter the index of the object: ";
            cin >> index;
            cubes[index].printDimensions();
            break;
        }
        case 'e':
        {
            float minArea = std::numeric_limits<float>::max();
            int minIndex = -1;

            for (size_t i = 0; i < cubes.size(); ++i)
            {
                if (cubes[i].getArea() < minArea && cubes[i].getVolume() != cubes[i].getArea())
                {

                    minArea = cubes[i].getArea();
                    minIndex = i;
                }
            }

            if (minIndex != -1)
            {
                cout << "Object with smallest area, not a cube: ";
                cubes[minIndex].printDimensions();
            } else
            {
                cout << "No object found satisfying the condition." << std::endl;
            }
            break;
        }
        case 'f':
        {
            cout << "Exiting the program." << endl;
            break;
        }
        default:
        {
            cout << "Invalid choice. Please enter a valid option." << endl;
            break;
        }
        }

    } while(choice != 'f');
    return 0;
}
