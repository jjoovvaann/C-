#include<iostream>
#include<string>

class Covek
{
private:
    std::string ime;
    std::string prezime;
    std::string adresa;
    std::string telefon;
public:
    Covek(std::string ime, std::string prezime, std::string adresa, std::string telefon)
        : ime(ime), prezime(prezime), adresa(adresa), telefon(telefon) {}
};

class Stedac
{
private:
    static double kamata;
    static int brojStedaci;
    Covek lice;
    double bilnas;
    double kredit;

public:
    Stedac(std::string ime, std::string prezime, std::string adresa, std::string telefon, double bilans, double kredit)
        : lice(ime, prezime, adresa, telefon), bilans(bilans), kredit(kredit)
    {
        brojStedaci++;
    }

    static double getKamata()
    {
        return kamata;
    }

    static voidsetKamata(double newKamata)
    {
        kamata = newKamata;
    }
    static int getBrojStedaci()
    {
        return brojStedaci;
    }

};

double Stedac::kamata = 0.0;
int Stedac::brojStedaci = 0;

int main()
{
    Stedac::setKamata(0.05);

    Stedac stedac1("Jovan", "Ljatkoski", "Londonska","123456", 1000.0, 0.0);

    std::cout<<"Number of savers: "<< Stedac::getBrojStedaci()<<std::endl;

    return 0;
}
