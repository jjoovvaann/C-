#include <iostream>

using std::cout;
using std::cin;
using std::endl;

inline double circleArea(int n)
{
    return n * n * 3.14;
}

int main()
{
    double radius;
    cout<<"Enter the radius\n";
    cin >> radius;

    cout<< "Area is "<<circleArea(radius);

    return 0;
}
