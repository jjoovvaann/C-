#include<iostream>

class Dropki
{
private:
    int numerator;
    int denominator;
public:
    Dropki(int num =1, int den = 1)
    {
        if(den == 0)
        {
            std::cerr << "Error: Can't be zero" << std::endl;;
            den = 1;
        }
        numerator = num;
        denominator = den;
        reduceFraction();
    }

    int gcd(int a, int b)
    {
        if(b==0)
            return a;
        return gcd(b,a%b);
    }

    void reduceFraction()
    {
        int commonDivisor = gcd(numerator, denominator);
        numerator /= commonDivisor;
        denominator /= commonDivisor;

        if (denominator < 0)
        {
            numerator = -numerator;
            denominator = -denominator;
        }
    }
    Dropki operator+(const Dropki& other)
    {
        int num = numerator * other.denominator + other.numerator * denominator;
        int den = denominator * other.denominator;
        return Dropki(num, den);
    }


    Dropki operator-(const Dropki& other)
    {
        int num = numerator * other.denominator - other.numerator * denominator;
        int den = denominator * other.denominator;
        return Dropki(num, den);
    }


    Dropki operator*(const Dropki& other)
    {
        int num = numerator * other.numerator;
        int den = denominator * other.denominator;
        return Dropki(num, den);
    }


    Dropki operator/(const Dropki& other)
    {
        int num = numerator * other.denominator;
        int den = denominator * other.numerator;
        return Dropki(num, den);
    }


    void printFraction()
    {
        std::cout << numerator << "/" << denominator;
    }


    void printAsReal()
    {
        double result = static_cast<double>(numerator) / denominator;
        std::cout << result;
    }
};

int main()
{
    Dropki fraction1(2, 4);
    Dropki fraction2(3, 5);


    Dropki sum = fraction1 + fraction2;
    Dropki diff = fraction1 - fraction2;
    Dropki product = fraction1 * fraction2;
    Dropki quotient = fraction1 / fraction2;


    std::cout << "Sum: ";
    sum.printFraction();
    std::cout << " = ";
    sum.printAsReal();
    std::cout << std::endl;

    std::cout << "Difference: ";
    diff.printFraction();
    std::cout << " = ";
    diff.printAsReal();
    std::cout << std::endl;

    std::cout << "Product: ";
    product.printFraction();
    std::cout << " = ";
    product.printAsReal();
    std::cout << std::endl;

    std::cout << "Quotient: ";
    quotient.printFraction();
    std::cout << " = ";
    quotient.printAsReal();
    std::cout << std::endl;

    return 0;
}

