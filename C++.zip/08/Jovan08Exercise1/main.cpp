#include <iostream>

class Complex {
public:
    Complex(double = 0.0, double = 0.0);
    Complex operator+(const Complex&) const;
    Complex operator-(const Complex&) const;
    Complex operator*(const Complex&) const;
    Complex operator*(int) const;
    const Complex& operator=(const Complex&);
    const Complex& operator+=(const Complex&);
    const Complex& operator-=(const Complex&);
    const Complex& operator*=(const Complex&);
    const Complex& operator*=(int);
    bool operator==(const Complex&) const;
    bool operator!=(const Complex&) const;

    friend std::ostream& operator<<(std::ostream&, const Complex&);
    friend std::istream& operator>>(std::istream&, Complex&);

private:
    double real;
    double imaginary;
};

Complex::Complex(double r, double i) : real(r), imaginary(i) {}

Complex Complex::operator+(const Complex& operand2) const
{
    return Complex(real + operand2.real, imaginary + operand2.imaginary);
}

Complex Complex::operator-(const Complex& operand2) const
{
    return Complex(real - operand2.real, imaginary - operand2.imaginary);
}

Complex Complex::operator*(const Complex& operand2) const
{
    return Complex(
        (real * operand2.real) - (imaginary * operand2.imaginary),
        (real * operand2.imaginary) + (imaginary * operand2.real)
        );
}

Complex Complex::operator*(int number) const
{
    return Complex(real * number, imaginary * number);
}

const Complex& Complex::operator=(const Complex& right)
{
    real = right.real;
    imaginary = right.imaginary;
    return *this;
}

const Complex& Complex::operator+=(const Complex& other)
{
    *this = *this + other;
    return *this;
}

const Complex& Complex::operator-=(const Complex& other)
{
    *this = *this - other;
    return *this;
}

const Complex& Complex::operator*=(const Complex& other)
{
    *this = *this * other;
    return *this;
}

const Complex& Complex::operator*=(int number)
{
    *this = *this * number;
    return *this;
}

bool Complex::operator==(const Complex& other) const
{
    return (real == other.real) && (imaginary == other.imaginary);
}

bool Complex::operator!=(const Complex& other) const
{
    return !(*this == other);
}

std::ostream& operator<<(std::ostream& out, const Complex& complex)
{
    out << '(' << complex.real << ", " << complex.imaginary << ')';
    return out;
}

std::istream& operator>>(std::istream& in, Complex& complex)
{
    char discard;
    in >> discard >> complex.real >> discard >> complex.imaginary >> discard;
    return in;
}

int main()
{
    Complex x, y(4.3, 8.2), z(3.3, 1.1);

    std::cout << "Enter a complex number in the format (a, b): ";
    std::cin >> x;

    std::cout << "x: " << x << std::endl;
    std::cout << "y: " << y << std::endl;
    std::cout << "z: " << z << std::endl;

    x = y + z;
    std::cout << "x = y + z: " << x << " = " << y << " + " << z << std::endl;

    x = y - z;
    std::cout << "x = y - z: " << x << " = " << y << " - " << z << std::endl;



    return 0;
}
