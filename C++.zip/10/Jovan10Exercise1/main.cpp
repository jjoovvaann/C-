#include<iostream>
#include<cstring>

using namespace std;

using std::cout;
using std::cin;
using std::endl;

class Employee
{
protected:
    char ime[50];
    char prezime[50];
    int godina_na_vrabotuvanje;
public:
    Employee() {}
    void setDetails(const char* i, const char* p, int g)
        {
            strcpy(ime, i);
            strcpy(prezime, p);
            godina_na_vrabotuvanje = g;
        }

    void display()
        {
        cout << "Name" << ime << " " << prezime << endl;
        cout<<"Year od Employment: " << godina_na_vrabotuvanje<< endl;
        }
};

class Professor : public Employee
{
private:
    char zvanje[50];
    char oblast[50];
    int br_predmeti;
public:
    Professor() {}
    void setDetails(const char* i, const char* p, int g, const char* zv, const char* obl, int br)
    {
        Employee::setDetails(i, p, g);
        strcpy(zvanje, zv);
        strcpy(oblast, obl);
        br_predmeti = br;
    }

    void display()
    {
        Employee::display();
        cout << "Title" << zvanje << endl;
        cout << "Field" << oblast << endl;
        cout << "Number of Courses" << br_predmeti << endl;
    }
};

class Assistant : public Employee
{
private:
    char zvanje[50];
    char mentor[50];
    int br_predmeti;
public:
    Assistant() {}
    void setDetails(const char* i, const char* p, int g, const char* zv, const char* m, int br)
    {
        Employee::setDetails(i, p, g);
        strcpy(zvanje, zv);
        strcpy(mentor, m);
        br_predmeti = br;
    }
    void display()
    {
        Employee::display();
        cout << "Title: " << zvanje << endl;
        cout << "Mentor: " << mentor << endl;
        cout << "Number of Courses: " << br_predmeti << endl;
    }
};

class Demonstrator : public Employee
{
private:
    char rabotno_vreme[50];
public:
    Demonstrator() {}
    void setDetails(const char* i, const char* p, int g, const char* rv)
    {
        Employee::setDetails(i, p, g);
        strcpy(rabotno_vreme, rv);
    }
    void display()
    {
        Employee::display();
        cout << "Working Hours: " << rabotno_vreme << endl;
    }
};

int main()
{
    const int MAX_EMPLOYEES = 100;
    Employee* employees[MAX_EMPLOYEES];
    int numEmployees = 0;
    int choice;

    do
    {
        cout << "\n1. Add a new employee to the list" << endl;
        cout << "2. Display the list" << endl;
        cout << "3. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            int employeeType;
            cout << "\nEnter employee type";
            cin >> employeeType;

            if (employeeType == 1)
            {
                employees[numEmployees] = new Professor();
                char i[50], p[50], zv[50], obl[50];
                int g, br;
                cout << "Enter name, surname, year of employment, title, field, number of courses: ";
                cin >> i >> p >> g >> zv >> obl >> br;
                employees[numEmployees]->setDetails(i, p, g, zv, obl, br);
            } else if (employeeType == 2)
            {
                employees[numEmployees] = new Assistant();
                char i[50], p[50], zv[50], m[50];
                int g, br;
                cout << "Enter name, surname, year of employment, title, mentor, number of courses: ";
                cin >> i >> p >> g >> zv >> m >> br;
                employees[numEmployees]->setDetails(i, p, g, zv, m, br);
            } else if (employeeType == 3)
            {
                employees[numEmployees] = new Demonstrator();
                char i[50], p[50], rv[50];
                int g;
                cout << "Enter name, surname, year of employment, working hours: ";
                cin >> i >> p >> g >> rv;
                employees[numEmployees]->setDetails(i, p, g, rv);
            } else
            {
                cout << "Invalid employee type!" << endl;
                continue;
            }

            numEmployees++;
            break;
        }
        case 2:
            cout << "\nEmployee List:" << endl;
            for (int i = 0; i < numEmployees; ++i) {
                cout << "Employee " << i + 1 << ":" << endl;
                employees[i]->display();
                cout << endl;
            }
            break;
        case 3:
            cout << "Exit" << endl;
            break;
        default:
            cout << "Invalid choice!" << endl;
        }
    } while (choice != 3);
    return 0;
}




